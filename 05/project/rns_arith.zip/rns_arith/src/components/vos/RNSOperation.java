package components.vos;

public class RNSOperation {

	public String label;
	public String operation;
	
	public RNSOperation(String label, String operation)
	{
		this.label = label;
		this.operation = operation;
	}
}
