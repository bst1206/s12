package com.stackbaek.rnsarith.util.test;

import junit.framework.Test;
import junit.framework.TestSuite;

public class RNSUtilTestSuite {

	public static Test suite() {
		TestSuite suite = new TestSuite();
		suite.addTest(new RNSUtilTest("test_workflow"));
//		suite.addTest(new RNSUtilTest("testValidateModuli"));
//		suite.addTest(new RNSUtilTest("testIsCoPrime"));
//		suite.addTest(new RNSUtilTest("testConverToRNS"));
		return suite;
	}
	
}
